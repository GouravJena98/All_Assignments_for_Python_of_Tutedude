# modules are the files which is used to separate the data from main code so that it is more reliable and easy to use.

# ways to import modules:

# 1. import module_name --> it import the whole module as a single entity with its name to access all calsses and fun.s
# 2. from module_name import function_name --> it import only the specified function or class from the module
# 3. from module_name import *  --> it import all the classes and functions from the module (not recommended)
# 4. import module_name as alias_name --> it import the whole module as a single entity with an alias name so no need to write the complete module name repeatedly to access all classes and functions
# 5. from module_name import function_name as alias_name  --> it import only the specified function or class from the module with an alias name
# 6. from module_name import * as alias_name (not recommended)  --> it import all the classes and functions from the module with an alias name

# 7. import module_name, module_name2 (not recommended) --> it import multiple modules at once

# 8. from module_name import function_name, function_name2 (not recommended)
# 9. from module_name import * , function_name (not recommended)
# 10. from module_name import function_name as alias_name, function_name2 as alias_name2 (not recommended)

import math
print(math.pi)

from math import pi#it import only pi class from the math module 
print(pi)

from math import *
print(pi)