#String formatting : 
name="gourav"
num=len(name)*3
print("Hello, %s. Your lucky number is %d" %(name,num))
print("Hello, {}. Your lucky number is {}".format(name,num))
print(f"Hello, {name}. Your lucky number is {num}")
print("Hello, {0}. Your lucky number is {1}".format(name,num))
print("Hello, {name}. Your lucky number is {num}".format(name=name,num=num))
print("Hello, {n}. Your lucky number is {l}".format(n=name,l=num))
print("Hello, {0}. Your lucky number is {1}. {0}, {1}".format(name,num))
