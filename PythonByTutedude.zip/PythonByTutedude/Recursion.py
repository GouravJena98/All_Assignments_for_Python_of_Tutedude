#Calling the function repeatedly insid its function defination :

#To see how many time the output tunnel can print the output using recursion :
import sys
print(sys.getrecursionlimit())#it will print the limit of recursion in python by default
#you can change the limit of recursion using setrecursionlimit() function of sys module:
sys.setrecursionlimit(2000) #it limeit upto 1996 
#if you unable to find the limit the set a counter inside the recursion to count how many timea the fun is called.

#Byt writing this there is limitation of 996 approx 100 time of printing the code 
def python():
    print("Python")
    python()

python()