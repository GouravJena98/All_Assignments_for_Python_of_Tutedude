
#Dictionary in Python :

d1={'a':"apple",'b':"ball",'c':"chatanya",'d':"dog"}

#what is the difference between add and update in dictionary?
#Add is used to add a single element to the dictionary where as update is used to add multiple elements to the dictionary at once.
#Add can only add one key value pair at a time where as update can add multiple key value pairs at a time.
#Add will give error if the key is already present in the dictionary where as update will update the value of the key if the key is already present in the dictionary.

#Add elemet to dictionary:
d1['e']="elephant"
print(d1)
#Update element to dictionary:
d1.update({'f':"fish"})
print(d1)

#Remove element from dictionary:
d1.pop('c')
print(d1)
d1.popitem()#it will remove the last element of the dictionary
print(d1)  
#to delete an element from dictionary:
del d1['b']
print(d1)
# del d1 #it will delete the whole dictionary
# print(d1) #it will give error as the dictionary is deleted
d1.clear() #it will clear the whole dictionary
print(d1)

#List in Python :
l1=["apple","ball","chatanya","dog"]
l2=[1,2,3,4,5,6,7,8,9,10]
print(l1+l2) #it will concatenate the two lists
print(l1*3) #it will repeat the list 3 times

# Element-wise multiplication (if both lists are of the same length)
# For demonstration, let's multiply the elements of l2 by 2
print([x * 2 for x in l2])

l1.remove("dog")
print(l1)

del l2[0:5]
print(l2)








