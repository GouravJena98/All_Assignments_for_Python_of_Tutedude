#Frame give more flexibility while layout the component of window 

import tkinter as tk
from tkinter import ttk

window=tk.Tk()
window.title("My Application")

# # 3part :--
# #here if we want to sub devide the main window into sub-window do use of the framework : 
# my_frame=ttk.Frame()#now this frame is a sub window that we can put the widgets inside it --> let label1 put inside the first window and rest are in another 
# my_frame.pack(side="top",fill="both",expand=True)#it will create a frame after all label where we can use other components by telling the component to goto that perticular space 
# #By default all the componet will goto the main window if any component will move to the sub window we have to specify it in the Label() part i.e use that frame as first argument by default are in main window or you can explicitly mentioned it 

# # 2nd part :--
# window.minsize(height=  300,width=400)#it take atleast two argument(width and height) to run else show error.
# label1=tk.Label(my_frame,text="Hello World!",bg="orange")
# #so the reset spaces beside it will waste -- if we want to spread all the vertical space --use fill="y" i.e say the component to use all the vertical(y axis) space 
# # label1.pack(side="left",fill="y",expand=True)
# # label1.pack(side="left",fill="x",expand=True)
# #here if we do fill="x" it show no change as we do side="left" so the horizontal space is fixed as per the width of label but the vertical space is empty to fill --- we can see it by doing side="top" 
# #Another way by using expand=True argument we can expand the label as per the screen is expanded 
# #if we use fill="both" then : 
# label1.pack(side="top",fill="both",expand=True)#here sid="both" reserve the left side ,fill="both" means utilize both x and y axis given to it and expan means when we expand the component expand as per the window expansion for both direction on window 

# label2=tk.Label(window,text="How are you?",bg="white")
# label2.pack(side="top",fill="both",expand=True)
# label3=tk.Label(window,text="Have a nice Day..",bg="green")
# label3.pack(side="top",fill="both",expand=True)
# #The component get anchored at the top i.e align towords the top one after another -- if want to change the side of the label then use side="" attribute in the pack() fun. of label then it reserver the left space of the window upto that text length so the labels are appear side by side of one another they cannot come one below another at left side if do all the label of pack(side="left") i.e window reserve the vertical space :

#4th part : 
my_frame=ttk.Frame()
my_frame.pack(side="left",fill="both",expand=True)

window.minsize(height=  300,width=400)
label1=tk.Label(my_frame,text="Hello World!",bg="orange")
label1.pack(side="top",fill="both",expand=True)

#this two labels are in the main window but the albel1 is in the frame 
label2=tk.Label(window,text="How are you?",bg="white")
label2.pack(side="top",fill="both",expand=True)
label3=tk.Label(window,text="Have a nice Day..",bg="green")
label3.pack(side="top",fill="both",expand=True)

window.mainloop()
