#Previously we saw the tkinter module now we will see the ttk module  --> ttk is the improved theme version of Tk module: 
import tkinter as tk
import tkinter.font as tfont
from tkinter import ttk

window=tk.Tk()
window.title("ttk")
window.minsize(width=400,height=300)

custom_font=tfont.Font(family="Times New Roman",size=15,weight="bold")
label=ttk.Label(text="Hello World!",font=custom_font)
label.pack()
label["text"]="Have a nice Day"
label.config(text="Love mama")

def fun():
    inp=user_input.get()
    label.config(text=inp)

user_input=ttk.Entry(width=30)
user_input.pack()
button=ttk.Button(text="Click", command=fun)
button.pack()

window.mainloop()

