import tkinter as tk
import tkinter.font as tfont

#There is a class inside tkinter module called Tk help to create a window 
window=tk.Tk() #by this only we will create a obj of Tk class of tkinter module imported 

#now to change the title of window : 
window.title("Gourav Application")

#we can add a text inside the window by help of class called label of tk module : 
label=tk.Label(text="Hello World\n\nHave a nice Day...", font=("Times New Roman",20,"bold","italic")) #By writing this only text will not appear as --> when ever we create any component/elm inside the window using tkinter library for make that component implemented inside window use pack method # To change the font use -- font=() and give the detail in tuple form = like font_style,size,bold in double code
#we can also use font class in the font module or package inside the font library then can use that font obj created using font class in my label class as font argument : how to do : 
#create a custom font : 
custom_font= tfont.Font(family="Times New Roman",size=15,slant='italic',weight="bold") #in tk library we have module font and inside that module we have a class Font() and inside it we cna give :() font_family= ,size=,stant= ) and in label calss use it in font argument 
#it show error when we do only import the tkinter module as tk we have to explicitly import this font module --> "import tkinter.font as tfont"  and use tfont instead of tk.font
label1=tk.Label(text="..How are You..", font=custom_font)
label1.pack()
#There is a another way to change th font after label creation is : 
label2=tk.Label(text="...Radhe Radhe...")
label2.pack()
#By configure the label data : 
label.config(font=("Courier New",25,"underline","bold","italic"))

label.pack() # it brings the component on window 
#instead of pack() we can use these #pack(), grid(), or place()
#we can use : obj.pack(side="left"or"top"or"right"or"bottom") , obj.pack(expand=1 0r 0)-bring the text to center to window, obj.pack(fill='x','y','both','none') , obj.pack(ipadx=,ipady=), obj.pack(padx=,pady=), obj.pack(anchor=)-say where the packer is to place each slave in its parcel
#when you use the pack method the window get automatically resize according to label to be best fit 
#To define the min size for window use : 
window.minsize(width=400,height=300) #This is set the min size that can be increase the size accoding to the content 


#But to run this obj continuously on window use a fun mainloop() of obj : 
window.mainloop() #i.e it will listen to the user for doing any activity



