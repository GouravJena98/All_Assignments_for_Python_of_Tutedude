# s-1: import tkinter -->
from tkinter import *
import tkinter.messagebox

# s-2: GUI interaction -->
window=Tk()

# s-3: Adding Inputs --> 
window.title("My First Tkinter App")#Give title for app 

inp=Label(window,text="Hello World")
inp.pack()

window.geometry("500x700")#Dimension to appear the screen in the min size that you can maximize
window.config(bg="yellow")#To give background color 

#Creating Frames in the app : 
frame1=Frame(window,bg="red",width=300,height=300,cursor="dot") #you can chage your cursor by moving inside the frame area by cursor attribute of Frame class
frame1.pack(side=TOP) #To get that frame to display on the window use pack fun. 
#Let create anoter frame 
frame2=Frame(window,bg="green",width=300,height=300,cursor="dotbox") 
frame2.pack(side=BOTTOM)#we can specify at which side the frame should be by side= attribute 

#Now Creating the Buttons inside the Frames : And Don't Forget to Pack()
button1=Button(frame1,text="Hello Everyone",bg="blue")#BY creating the butoon the frame bg color disappear to set the frame backgound appear you have to define its frame.place(x=,y=) so frame will be appear
button1.pack()
button2=Button(frame2,text="BYE Everyone",bg="pink")
button2.pack()
#To specify the button size and location :
button3=Button(frame1,text="Logged",bg="pink")
button3.pack()
#it is applicable for referencing to window only 
# button3.place(x=50, y=80, width=20, height=20)
# button3.grid(row=1, column=2, padx=10, pady=10) #row, column: define button’s position in the grid---padx, pady: spacing around the button----width, height: number of text units (not pixels)

#Let see for frame : Here as we create a new frame which will create after frame1 then the area of frame will work only in the frame1 buttonc
frame = Frame(window, bg="lightgray", width=200, height=200)
frame.place(x=150, y=80)

btn = Button(frame, text="Click Me", bg="lightblue")
btn.place(x=80, y=60, width=60, height=60)

# # s-4: Mainloop run --> We can write single mainloop for all the windows that will work for all the code at the end of all code with reference to any window  --> but writing all the separately after closing one loop anoter will start for anotjer set of code
# window.mainloop() 

#Now create a Enrty box annd Grid layout :- 
window1=Tk()
window1.title("Entry-Box")
window1.geometry("250x50")

label1=Label(window1,text="Mail")

'''
     0|1 |2 |
0|____|__|__|  --> if we say row=0 and col=1 then my label is at (0,1) position
1|____|__|__|
2|____|__|__|
'''
label1.grid(row=0,column=1)
label2=Label(window1,text="Password")
label2.grid(row=1,column=1)

e1=Entry(window1,width=48,borderwidth=5)
e1.grid(row=0,column=2)
e2=Entry(window1,width=48,borderwidth=5)
e2.grid(row=1,column=2)

# # s-4: Mainloop run --> We can write single mainloop for all the windows that will work for all the code at the end of all code with reference to any window  --> but writing all the separately after closing one loop anoter will start for anotjer set of code
#window1.mainloop()


# Learn about Pack() fun. : 
window2=Tk()
window2.title("Pack Practice")
window2.geometry("500x500")

label3=Label(window2,text="Label-1",bg="red",fg="white")
label4=Label(window2,text="Label-2",bg="blue",fg="white")

label3.pack(side=TOP,fill=X,expand=False)
label4.pack(side=LEFT,fill=Y,expand=False)#if here make expand-True then the label keep extra spaces at eh left side for widgets 
'''
Argument for pack will be : 
side : Which side of the parent widget to “stick” the widget to : tk.TOP (default), tk.BOTTOM, tk.LEFT, tk.RIGHT (or strings "top", "bottom", "left", "right")
fill : Whether the widget should expand to fill extra space : NONE (default), X, Y, or BOTH
expand : If True, expand widget to take up any extra space in the parent : True or False (or integer 0/1)
padx, pady : External padding (in pixels) in the x- and y-directions : Integers or tuple (e.g. padx=10 or padx=(5, 15))
ipadx, ipady : Internal padding: add additional space inside the widget (ex: extra width or height) : Integers
anchor : When the widget does not fill all the space, where it is positioned : Combinations of "n", "s", "e", "w" (north, south, east, west) or "center" (default)

Disadvantage is : 
we can pack these labels in left,right,top and bottom only 
so instead of pack() we can use grid layout to place the element anywehre

'''
'''
# example : 
import tkinter as tk

root = tk.Tk()

lbl = tk.Label(root, text="Hello")
lbl.pack(
    side=tk.LEFT,
    fill=tk.Y,
    expand=True,
    padx=10,
    pady=5,
    ipadx=5,
    ipady=5,
    anchor="n"
)
'''

# # s-4: Mainloop run --> We can write single mainloop for all the windows that will work for all the code at the end of all code with reference to any window  --> but writing all the separately after closing one loop anoter will start for anotjer set of code
# window2.mainloop()

#Handling Buttons : 
window3=Tk()
window3.title("Button Handling")
window3.geometry("500x500")

#To make functional to button -->so to print message on console do -->
def log_entry():
     print("Logged In")
btn2=Button(window3,text="LogIn",command=log_entry,width=12,bg="red",fg="white",font=("bold",12,"italic"),activebackground="blue",activeforeground="yellow") #here activebackground/foreground is use to apply color during clicking transition
btn2.pack()

#Add Menubar : like in Notepaad
window4=Tk()
window4.title("Menu Bar")
window4.geometry("500x500")

menu=Menu(window4)

file=Menu(menu,tearoff=1) #if give tearoff =0-->then only dropdown submenu style is created but when give 1 by clicking the dotted line over the drop down menu option we cna get a floating menu option
#To add sub menu : 
file.add_command(label="New")
file.add_command(label="Open")
file.add_command(label="Save")
file.add_command(label="Save as")
file.add_separator()#TO add a horizontal line b/w the sub modules use this fun.
file.add_command(label="Page Setup")
file.add_command(label="Print")
file.add_separator()
file.add_command(label="Exit",command=window4.quit)

menu.add_cascade(label="File",menu=file)
window4.config(menu=menu)

edit=Menu(menu,tearoff=1)
edit.add_command(label="Undo")
edit.add_separator()
edit.add_command(label="Cut")
edit.add_command(label="Copy")
edit.add_command(label="Paste")
edit.add_command(label="Delete")
edit.add_separator()
edit.add_command(label="Clear Formating")
edit.add_command(label="Search with Bing")
edit.add_separator()
edit.add_command(label="Find")
edit.add_command(label="Find Text")
edit.add_command(label="Find Previous")
edit.add_command(label="Replace")
edit.add_command(label="Go to")
edit.add_separator()
edit.add_command(label="Select All")
edit.add_command(label="Time/Date")
edit.add_separator()
edit.add_command(label="Font")

menu.add_cascade(label="Edit",menu=edit)
window4.config(menu=menu)

view=Menu(menu,tearoff=1)
view.add_command(label="Zoom")
view.add_command(label="Status Bar")
view.add_command(label="Word Wrap")
view.add_command(label="Markdown")

menu.add_cascade(label="View",menu=view)
window4.config(menu=menu)

#Create a Message box : 
# -- For it we have to import a package=messagebox from module tkinter
tkinter.messagebox.showinfo("Info","Running Out of Time")

# s-4: Mainloop run --> We can write single mainloop for all the windows that will work for all the code at the end of all code with reference to any window  --> but writing all the separately after closing one loop anoter will start for anotjer set of code
# but by writing all mainloop at the end all window will open at a time 
window.mainloop()
window1.mainloop()
window2.mainloop()
window3.mainloop()
window4.mainloop()
# mainloop()#for messagebox 


