import tkinter as tk
import tkinter.font as tfont
from tkinter import ttk

#1. Tk(): 
window=tk.Tk()
window.title("Gourav Application")
window.minsize(height=700,width=800)


#2. Font change for label:
custom_font=tfont.Font(family="Times New Roman",size=15,weight='bold')

#3. Create a label
label=ttk.Label(text="Learn widgets",font=custom_font,padding=5)
label.pack()


#check button : -->it is combination of checkbox and text
label1=ttk.Label(text="Check Box",font=custom_font,padding=5)
label1.pack()

var=tk.StringVar() #it will store 0 or 1 value --- here IntVar() is a integer class 
def chekoption():
    if var.get()=="yes":
        label1.config(text="Agreed")  
        print(var.get())
    else:   
        label1.config(text="Not Agreed")  
        print(var.get())
    
 #instead of printing the integer value if we want to show the string value we can use StringVar() instead of IntVar() -->And use onvalue and offvalue in checkbutton  by this onvalue and offvalue instead of 0&1 it print a string
#we can pass command here like every butotn that we did . so by checking the check box the fun will call .
check_button=ttk.Checkbutton(text="Agree with terms and condition mentioned ?",command=chekoption,variable=var,onvalue= "yes",offvalue="No") #here on and off value decide the return value of var 
#And we can also retrieve the value of the ckeckbutton by using a variable like IntVar() or StringVar() -- it will store the value of checkbutton

# # it will give 1 or 0 which is present as its intial value --> os to get the current value define the fun. before button
# check_button=ttk.Checkbutton(text="Agree with terms and condition mentioned ?",variable=var)
# print(var.get()) #to get the value of checkbutton

check_button.pack() 

#Radio button : --> it is combination of multiple checkbox and text but only one can be selected at a time as thay are linked together by a variable
label2=ttk.Label(text="Radio Button",font=custom_font,padding=5)
label2.pack()

radio_var=tk.StringVar() #it will store the value of selected radio button
def radiooption():
    print(radio_var.get())
    label2.config(text=f"You are a  {radio_var.get()}")    
radio_button1=ttk.Radiobutton(text="Male",value="Male",variable=radio_var,command=radiooption)#value is use to use to show the value on terminal as per the Intvar() or Stringvar()  for radio_var variable 
radio_button2=ttk.Radiobutton(text="Female",value="Female",variable=radio_var,command=radiooption)
radio_button3=ttk.Radiobutton(text="Other",value="Other",variable=radio_var,command=radiooption)   
#here variable attribute is used to link with single variable so by selecting which bitton the return value of that butto will goto that variable
radio_button1.pack()
radio_button2.pack()
radio_button3.pack()
#to get the value of selected radio button we can use the variable linked with it like IntVar() or StringVar()  
# print(radio_var.get()) #to get the value of selected radio button


#Combo Box : --> it is used to select one value from a dropdown list
label3=ttk.Label(text="Combo Box",font=custom_font,padding=5)
label3.pack()

def combooption(event):
    print(combo_box.get())
    label3.config(text=f"You have selected  {combo_box.get()}")
    label4=ttk.Label(text=f"{combo_box.get()}",font=custom_font,padding=5)
    label4.pack()    
    
combo_box=ttk.Combobox(values=["Python","Java","C++","JavaScript","C#"])
#or we can also link a variable with combo box to get the value of selected option
# combo_var=tk.StringVar()
# combo_box=ttk.Combobox(values=("Python","Java","C++","JavaScript","C#"),textvariable=combo_var)  

#here user can write his own value at the place of selecting from the dropdown list but if want to restirct the user to select only from the list we can use state="readonly" in combobox
combo_box.config(state="readonly")
#or 
# combo_box=ttk.Combobox(values=["Python","Java","C++","JavaScript","C#"],state="readonly")
# or
# combo_box['state']='readonly'

combo_box.current(0) #to set the default value of combo box
combo_box.bind("<<ComboboxSelected>>",combooption) #to bind the event with the combo box
combo_box.pack()

# def display(event):#this event will take the event occure as argument
#     print(f"selected country is : {country_combo.get()}")
# #by writing this fun only nothing will happen until we bind this fun with the combobox
# combo_box.bind("<<ComboboxSelected>>",display) #to bind the event with the combo box here ComboboxSelected is a predefined event in tkinter for combobox when an option is selected


#List box : --> it is used to select one or more values from a list wher the options ate apperaed always
label5=ttk.Label(text="List Box",font=custom_font,padding=5)
label5.pack()   

def listoption(event):
    selected_indices=list_box.curselection() #to get the indices of selected items not the items i.e tuple of indices
    selected_items=[list_box.get(i) for i in selected_indices] #to get the selected items using the indices
    print("Selected items:",selected_items)
    label5.config(text=f"Selected items: {', '.join(selected_items)}")
    
items=["Apple","Banana","Cherry","Date","Elderberry","Fig","Grape"]
list_box=tk.Listbox(selectmode=tk.MULTIPLE) #to select multiple items we can use selectmode=tk.MULTIPLE
for item in items:
    list_box.insert(tk.END,item) #to insert items in the list box
list_box.bind("<<ListboxSelect>>",listoption) #to bind the event with the list box
list_box.pack()

#or
food_items=("Pizza","Burger","Pasta","Sandwich","Fries")
fav_food=tk.StringVar(value=food_items) #to link a variable with the list box
# tk.Listbox(listvariable=fav_food,selectmode=tk.SINGLE).pack() #to select single item we can use selectmode=tk.SINGLE
# tk.Listbox(listvariable=fav_food,selectmode=tk.MULTIPLE).pack() #to select multiple items we can use selectmode=tk.MULTIPLE #OR
# tk.Listbox(listvariable=fav_food,selectmode="browse").pack() #to select single item we can use selectmode="browse" #OR  

food_list=tk.Listbox(listvariable=fav_food,height=5,selectmode="extended")#height for how many ite to be showed as list and to select multiple items use selectmod attribute
food_list.pack()


#spin box : --> it is used to select a value from a range of values by clicking on up and down arrow buttons
label6=ttk.Label(text="Spin Box",font=custom_font,padding=5)
label6.pack()

def spinoption():
    print(spin_box.get())
    label6.config(text=f"Selected value: {spin_box.get()}")

#to set the inntial value we can use: 
counter=tk.IntVar(value=5)

spin_box=ttk.Spinbox(from_=0,to=20,command=spinoption,textvariable=counter,wrap=True) #to set the range of values #here from_ is used as there is a keyword from in python so to defferentiate b/w keyword and argument we use underscore
#if we wnat that when you reach the max again goto start again and when reach to min and start from max use wrap attribute bydefault wrap is False
#here instaed of giving the range of value we can specify our own values : 
# spin_box=ttk.Spinbox(values=(10,20,30,40,50),command=spinoption,textvariable=counter,wrap=True)
#spin_box=ttk.Spinbox(values=["A","B","C","D","E"],command=spinoption) #for string values we cannot use textvariable as it only works with int and float var
# spin_box=ttk.Spinbox(values=tuple(range(1,100,4)),command=spinoption,wrap=True) #here can use range function  by converting it to tuple

spin_box.pack()


window.mainloop()


