import tkinter as tk
import tkinter.font as tfont
from tkinter import ttk

#1. Tk(): 
window=tk.Tk()
window.title("Gourav Application")
window.minsize(height=  300,width=400)

#2. Font change for label:
custom_font=tfont.Font(family="Times New Roman",size=15,weight='bold')

#3. Create a label
label=ttk.Label(text="Hello Sagarika",font=custom_font,padding=5)
label.pack()

label["text"]="Have a Nice Day"
label.config(text="My new App")

#4. Text widges is mainly a text box which allow us to input a multiline text :
def fun_btn():
    inp_txt=user_inp.get()
    label.config(text=inp_txt)

#5. in Entry we have a single line text: Taking user inp using Entry() is come serially in the same line not shift to next line
user_inp=ttk.Entry(width=30)
user_inp.pack()

#6. Buttons :
button=ttk.Button(text="Push",command=fun_btn)
button.pack()
quit_btn=ttk.Button(text="Quit",command=window.destroy)
quit_btn.pack()

#10.  #To separate two widgets by a line use separator fun: 
var=ttk.Separator(orient="horizontal") #to show horizontal separator use orient="horizontal" --> then store it in the variable and pack it with the main window 
var.pack(fill="x",pady=10)#Bydefault it will not visible as it default 1px in size  -- so use fill argument to show it in the entire horizontal space i.e "fill=x"

#7. Text widgets :
text=tk.Text(height=5,width=25) #---> This is the text window #Basically by set nothing it takes the entire space which is left as i/p area -->To set its height and width of text window use height=no. of lines,width=each line width attribute
text.pack()
#By run it the cursor isnot blinking at anywhere  -- if you want to active the cursor at any textbox on window screen do : 
text.focus()#helop to go the cursor inside the box
#To insert the default text in the window : 
text.insert("1.0","Description") #it take 2 argument 1.position=where you want to do insertion (in float number in string format), 2.string want to show ---> here 1.0= 1 indicate the 1st line and digit after decimal say= character number for 0th character start writing  ---> we can overwrite tis inserted text
#To disapble any component(widgets) for any reason can do : 
text["state"]="disabled"#it will appear on window but is disables we cannot use
#TO enable it we can use a button : 
def on():
    text["state"]="normal"
    
#8.  enb=ttk.Button(text="Enable",command=on)
# enb.pack(side="left")
# #now how to retrive/fetch the text from widgets : like the get() in entry we have the get() method for text also :
# # print(text.get("1.0","end")) #pass argument (self,index1,index2) i.e which part of the text want to read or entire text -- for starting and ending position ---> "1.0" as index1 and for entire text read give "end" as index2 -->then print it -->By writing only this the inserted text only appear whatever you write further willnot show in console so :
# #To bring some value to consoele we need to sue a button :
def prn():
    print(text.get("1.0","end"))
# btn=ttk.Button(text="Submit",command=prn)
# btn.pack(side="left")
#9. But Frame to hold Enable and Submit buttons side by side just below the text box do :
btn_frame = ttk.Frame(window)
btn_frame.pack(pady=(10, 0))

enb = ttk.Button(btn_frame, text="Enable", command=on)
enb.grid(row=0, column=0, padx=(0, 5))  # Small gap between buttons

btn = ttk.Button(btn_frame, text="Submit", command=prn)
btn.grid(row=0, column=1, padx=(5, 0))  # Symmetric padding

#To give space b/w two component use padding : 
#There are tow ways to give padding : directly write insde the element == "padding=15"=for it padding apply for all the 4 side of elment as argument or use it in the pack() --> let we want padd in y axis 
#now give padding to the separator in the pack() 


window.mainloop()




