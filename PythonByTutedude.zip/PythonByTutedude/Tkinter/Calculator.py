import tkinter as tk
from tkinter import ttk
import time

class AnimatedCalculator:
    def __init__(self, root):
        self.root = root
        self.root.title("Animated Calculator")
        self.root.geometry("300x400")
        self.root.configure(bg="#1a1a1a")
        
        # Variables
        self.current = ""
        self.expression = ""
        
        # Display Frame
        self.display_frame = tk.Frame(root, bg="#1a1a1a")
        self.display_frame.pack(expand=True, fill="both", padx=10, pady=10)
        
        # Entry widget with animation
        self.equation = tk.StringVar()
        self.entry = tk.Entry(self.display_frame, 
                            font=("Arial", 20), 
                            textvariable=self.equation, 
                            justify="right",
                            bg="#2d2d2d",
                            fg="#ffffff",
                            bd=0,
                            highlightthickness=1,
                            highlightcolor="#3498db")
        self.entry.pack(expand=True, fill="both")
        
        # Buttons Frame
        self.buttons_frame = tk.Frame(root, bg="#1a1a1a")
        self.buttons_frame.pack(expand=True, fill="both", padx=10, pady=10)
        
        # Button layout
        self.create_buttons()
        
    def create_buttons(self):
        buttons = [
            ('7', '#333333'), ('8', '#333333'), ('9', '#333333'), ('/', '#ff9500'),
            ('4', '#333333'), ('5', '#333333'), ('6', '#333333'), ('*', '#ff9500'),
            ('1', '#333333'), ('2', '#333333'), ('3', '#333333'), ('-', '#ff9500'),
            ('0', '#333333'), ('.', '#333333'), ('=', '#3498db'), ('+', '#ff9500'),
            ('C', '#e74c3c')
        ]
        
        row = 0
        col = 0
        
        for (text, color) in buttons:
            if text == 'C':
                button = self.create_animated_button(text, color, lambda x=text: self.clear(), 2)
                button.grid(row=4, column=0, columnspan=2, sticky="nsew", padx=2, pady=2)
            else:
                button = self.create_animated_button(text, color, lambda x=text: self.click(x))
                button.grid(row=row, column=col, sticky="nsew", padx=2, pady=2)
                
            col += 1
            if col > 3:
                col = 0
                row += 1
                
        # Configure grid weights
        for i in range(5):
            self.buttons_frame.grid_rowconfigure(i, weight=1)
        for i in range(4):
            self.buttons_frame.grid_columnconfigure(i, weight=1)
            
    def create_animated_button(self, text, bg_color, command, colspan=1):
        button = tk.Button(self.buttons_frame, 
                          text=text,
                          font=("Arial", 16),
                          bg=bg_color,
                          fg="white",
                          bd=0,
                          relief="flat")
        
        def on_enter(e):
            button['background'] = self.lighten_color(bg_color)
            self.animate_button(button, 'enter')
            
        def on_leave(e):
            button['background'] = bg_color
            self.animate_button(button, 'leave')
            
        def on_click(e):
            self.animate_button(button, 'click')
            command()
            
        button.bind("<Enter>", on_enter)
        button.bind("<Leave>", on_leave)
        button.bind("<Button-1>", on_click)
        
        return button
    
    def animate_button(self, button, animation_type):
        if animation_type == 'enter':
            button.config(relief="raised")
        elif animation_type == 'leave':
            button.config(relief="flat")
        elif animation_type == 'click':
            original_color = button['bg']
            button.config(bg=self.lighten_color(original_color))
            self.root.after(100, lambda: button.config(bg=original_color))
            
    def lighten_color(self, color):
        # Convert hex to RGB and lighten
        rgb = tuple(int(color[i:i+2], 16) for i in (1, 3, 5)) if color.startswith('#') else (128, 128, 128)
        lighter_rgb = tuple(min(int(x * 1.2), 255) for x in rgb)
        return f'#{lighter_rgb[0]:02x}{lighter_rgb[1]:02x}{lighter_rgb[2]:02x}'
    
    def click(self, value):
        if value == '=':
            try:
                result = eval(self.expression)
                self.equation.set(result)
                self.expression = str(result)
            except:
                self.equation.set("Error")
                self.expression = ""
        else:
            self.expression += value
            self.equation.set(self.expression)
            
    def clear(self):
        self.expression = ""
        self.equation.set("")
        
if __name__ == "__main__":
    root = tk.Tk()
    calculator = AnimatedCalculator(root)
    root.mainloop()


