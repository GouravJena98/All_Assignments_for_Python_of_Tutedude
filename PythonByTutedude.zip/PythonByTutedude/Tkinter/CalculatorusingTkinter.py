#Step1 : importing 
from tkinter import *

#Step2 : gui interaction 
window=Tk()
window.title("Gourav Application")
window.geometry("500x500")


#Step3 : Adding the inputs 

#Entry Box : 
e=Entry(window,width=66,borderwidth=9)
e.place(x=0,y=10)

#Buttons : 

def click(num): #here 'e' is a tkinter entry widget obj so to get the value from it we use e.get() method  --
    #here e is the entry widget object where your input is stored and by using e.get() we get the value from that entry widget and e.get() return string value so we need to convert it to int or float as per our requirement
    # e = tk.Entry(window, width=20, font=('Arial', 14))
    # e.pack()
    result=e.get() #e is the obj which stores the value in the variable current
    e.delete(0,END) #it is use because when we click on any button the previous value remain there in the result so to avoid that we first delete the previous value from 0 to END then insert the new value
    e.insert(0,str(result)+str(num)) #here in insert(position,value) we are converting both to string to avoid error and to concatinate  

#numbers : 
b=Button(window,text="1",width=12,command=lambda: click(1))
b.place(x=10,y=60)
b=Button(window,text="2",width=12,command=lambda: click(2))
b.place(x=80,y=60)
b=Button(window,text="3",width=12,command=lambda: click(3))
b.place(x=170,y=60)
b=Button(window,text="4",width=12,command=lambda: click(4))
b.place(x=10,y=120) 
b=Button(window,text="5",width=12,command=lambda: click(5))
b.place(x=80,y=120)
b=Button(window,text="6",width=12,command=lambda: click(6))
b.place(x=170,y=120)
b=Button(window,text="7",width=12,command=lambda: click(7))
b.place(x=10,y=180)
b=Button(window,text="8",width=12,command=lambda: click(8))
b.place(x=80,y=180)
b=Button(window,text="9",width=12,command=lambda: click(9))
b.place(x=170,y=180)
b=Button(window,text="0",width=12,command=lambda: click(0))
b.place(x=10,y=240)
#operator buttons : 
def add():
    n1=e.get()
    global math
    math="addition"
    global i #we declar i as global variable 
    i=int(n1)
    e.delete(0,END)
    #i.e upto this when we press add the value inside the input box should deleted and store its int form in the i variable
def sub():
    n1=e.get()
    global math
    math="subtraction"
    global i #we declar i as global variable 
    i=int(n1)
    e.delete(0,END)
def mul():
    n1=e.get()
    global math
    math="multiplication"
    global i #we declar i as global variable 
    i=int(n1)
    e.delete(0,END)
def div():
    n1=e.get()
    global math
    math="division"
    global i #we declar i as global variable 
    i=int(n1)
    e.delete(0,END)

def equal(): #when press equal all the value should be calculated and show the result
    n2=e.get()
    e.delete(0,END)
    global i
    j=int(n2)
    if math=="addition":
        e.insert(0,i+j)
    elif math=="subtraction":
        e.insert(0,i-j)
    elif math=="multiplication":
        e.insert(0,i*j)
    elif math=="division":
        e.insert(0,i/j)
    
def clearinp():
    e.delete(0,END)

    
b=Button(window,text="+",width=12,command=add)
b.place(x=80,y=240)
b=Button(window,text="-",width=12,command=sub)
b.place(x=170,y=240)
b=Button(window,text="*",width=12,command=mul)
b.place(x=10,y=300)
b=Button(window,text="/",width=12,command=div)
b.place(x=80,y=300)
b=Button(window,text="=",width=12,command=equal)
b.place(x=170,y=300)    
b=Button(window,text="clear",width=12,command=clearinp)
b.place(x=10,y=350)    


#setp4 : mainloop
mainloop()
