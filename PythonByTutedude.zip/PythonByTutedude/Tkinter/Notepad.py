from tkinter import *
from tkinter import filedialog, messagebox, font
from tkinter.ttk import *

class GouravPad:
    def __init__(self, root):
        self.root = root
        self.root.title("GouravPad")
        self.root.geometry("800x600")
        self.filename = None
        
        # Create TextArea
        self.textarea = Text(self.root, undo=True)
        self.textarea.pack(expand=True, fill='both')
        
        # Create MenuBar
        self.menubar = Menu(self.root)
        self.root.config(menu=self.menubar)
        
        # File Menu
        self.file_menu = Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="File", menu=self.file_menu)
        self.file_menu.add_command(label="New", command=self.new_file)
        self.file_menu.add_command(label="Open", command=self.open_file)
        self.file_menu.add_command(label="Save", command=self.save_file)
        self.file_menu.add_command(label="Save As", command=self.save_as)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="Exit", command=self.root.quit)
        
        # Edit Menu
        self.edit_menu = Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="Edit", menu=self.edit_menu)
        self.edit_menu.add_command(label="Cut", command=lambda: self.textarea.event_generate("<<Cut>>"))
        self.edit_menu.add_command(label="Copy", command=lambda: self.textarea.event_generate("<<Copy>>"))
        self.edit_menu.add_command(label="Paste", command=lambda: self.textarea.event_generate("<<Paste>>"))
        self.edit_menu.add_separator()
        self.edit_menu.add_command(label="Undo", command=self.textarea.edit_undo)
        self.edit_menu.add_command(label="Redo", command=self.textarea.edit_redo)
        
        # Format Menu
        self.format_menu = Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="Format", menu=self.format_menu)
        self.format_menu.add_checkbutton(label="Word Wrap", command=self.toggle_wrap)
        self.format_menu.add_command(label="Font", command=self.change_font)
        
        # Help Menu
        self.help_menu = Menu(self.menubar, tearoff=0)
        self.menubar.add_cascade(label="Help", menu=self.help_menu)
        self.help_menu.add_command(label="About", command=self.show_about)

    def new_file(self):
        self.textarea.delete(1.0, END)
        self.filename = None
        self.root.title("GouravPad")

    def open_file(self):
        self.filename = filedialog.askopenfilename(defaultextension=".txt",
                                                 filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
        if self.filename:
            self.textarea.delete(1.0, END)
            with open(self.filename, "r") as f:
                self.textarea.insert(1.0, f.read())
            self.root.title(f"GouravPad - {self.filename}")

    def save_file(self):
        if not self.filename:
            self.save_as()
        else:
            with open(self.filename, "w") as f:
                f.write(self.textarea.get(1.0, END))

    def save_as(self):
        try:
            self.filename = filedialog.asksaveasfilename(defaultextension=".txt",
                                                       filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")])
            if self.filename:
                with open(self.filename, "w") as f:
                    f.write(self.textarea.get(1.0, END))
                self.root.title(f"GouravPad - {self.filename}")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def toggle_wrap(self):
        if self.textarea.cget("wrap") == "none":
            self.textarea.configure(wrap=WORD)
        else:
            self.textarea.configure(wrap=NONE)

    def change_font(self):
        top = Toplevel(self.root)
        top.title("Font")
        top.geometry("200x200")
        
        font_list = list(font.families())
        font_var = StringVar(value=font_list[0])
        
        font_combo = Combobox(top, textvariable=font_var, values=font_list)
        font_combo.pack(pady=10)
        
        def apply_font():
            self.textarea.configure(font=(font_var.get(), 12))
            top.destroy()
        
        Button(top, text="Apply", command=apply_font).pack()

    def show_about(self):
        messagebox.showinfo("About GouravPad", "GouravPad\nA simple text editor\nCreated by Gourav")

if __name__ == "__main__":
    root = Tk()
    app = GouravPad(root)
    root.mainloop()
