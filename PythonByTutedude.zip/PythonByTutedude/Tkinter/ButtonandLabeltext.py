import tkinter as tk
import tkinter.font as tfont
from tkinter import ttk

#Button and change label text: 
window=tk.Tk()
window.title("Learn")
window.minsize(width=400,height=400)

custom_font=tfont.Font(family="Times New Roman",size=15,weight="bold")
label=tk.Label(text="Hello World!",font=custom_font)
label.pack()
#Now want to change the text : -->use the label obj and use syntax : label["text"]="Have a nice Day"
label["text"]="Have a nice Day"
#THere is another way to chage the text using config method : --i.e we can change any property by config
# label.config(font=("Courier New",35))
label.config(text="Love mama")

#uUttons : 
count=1
def fun_button():
    global count
    count+=1
    print("Gourav WEDS Sagarika")
    label["text"]="Gourav WEDS Sagarika"
    print("No. of click: ",count)
    

    
button=tk.Button(text="Click",command=fun_button) # the "command" argument take the fun. name which is called when the button is pressed 
button.pack()

#Entry Component: -->it is use to take i/p from user 
user_inp = tk.Entry(width=30) #make obj of the class Entry() 
user_inp.pack()
label2=tk.Label(text="Passowrd : ",font=custom_font)
label2.pack()
inp=tk.Entry(width=30,show="@")#, Now to encrypt the password text we will use show= attribute which will show to the user what ever we want 
inp.pack()
#To fetch the value i.e we use the get method to return the current string for use on terminal
# print("Name : ",user_inp.get(),"Password : ",inp)#it doesnot print anything as we print it before user enter the i/p --> so to see the i/p text we will attach the label with button so by clicking the button it will show the ooutput
label3=tk.Label(text="Inputed Text: ",font=custom_font)
label3.pack()
def fun():
    nm=user_inp.get()
    ps=inp.get()
    label3["text"]=f"Name: {nm} and Password: {ps}"
button2=tk.Button(text="Click Output",command=fun)
button2.pack()

#now to Quit the window we have a destroy fun. :
quitbtn=ttk.Button(text="QuitWindow",command=window.destroy)
quitbtn.pack()
window.mainloop()
