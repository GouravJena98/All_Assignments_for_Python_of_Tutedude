import re

# 1. match()
pattern1 = r"Apple"
print(re.match(pattern1, "Appleapp"))
print(re.match(pattern1, "aApple"))

print()

pattern = r"cat"
text = "catapult"
match = re.match(pattern, text)
if match:
    print("Matched:", match.group()) # Output: Matched: cat
    print("Span:", match.span()) # Output: Span: (0, 3)
    print("Start:", match.start()) # Output: Start: 0
    print("End:", match.end()) # Output: End: 3
else:
    print("No match")
    
print()    

pattern2="gouravjenasagarika"
print(re.findall(pattern2,"gouravjenasagarika"))
print(re.findall("sagarika",pattern2))

print()

text = "dog cat dog"
pattern3 = r"dog"

print(re.match(pattern3, text)) # Matches only if 'dog' is at start
print(re.search(pattern3, text)) # Finds first 'dog' anywhere
print(re.findall(pattern3, text))
    

string="It is a dog"
pattern4="^It is a"
print(re.findall(pattern4,string))
pattern4="a dog$"
print(re.findall(pattern4,string))
     
    
    
    
    
    
    
    