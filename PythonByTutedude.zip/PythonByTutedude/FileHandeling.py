#Two way to open and close a file : 

# #1. -->
# f1=open("Factorial.py","r")
# print(f1.read())
# f1.close()

# #2. -->
# with open("Factorial.py","r") as f1:
#     a=f1.read()
#     print(a)


# f1=open("Factorial.py","r")
# print(f1.read(10)) #we can read some selected no. of characters by passing the no. of characters in read() function
# print(f1.readline()) #it will read only one line of the file
# print(f1.readlines()) #it will read all the lines of the file and return it in a list format
# f1.close()

f2=open("file.txt","w") #it will create a new file if the file is not present in the directory
f_write=f2.write("This is file 2\n")
print(f_write) #it will return the no. of characters written in the file
f2.close()

f3=open("file.txt","a") #it will append the data to the existing file
f3.write("This is file 3\n")
f3.close()

f4=open("file.txt","r")
print(f4.read())
f4.close()





