 # 0! = 1
#  1!=1*0! = 1*1=1
#  2!=2*1!=2*1=2
#  3!=3*2!=3*2=6
#  4!=4*3!=4*6=24
#  5!=5*4!=5*24=120

def factorial(n):   
    if n==0 or n==1:
        return 1
    else:
        return n*factorial(n-1)
print("Factorial of 5 is:",factorial(5))