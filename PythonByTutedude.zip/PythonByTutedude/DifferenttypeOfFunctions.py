# Lambda Function : 

# lambda arguments : expression
add = lambda a,b : a+b
print(add(5,10))
# it is used to create small anonymous functions at runtime
# it can have any number of arguments but only one expression
# it is used when we need a small function for a short period of time
# it is used in higher order functions like map(), filter(), reduce() etc.

# Map Function :
# it is used to apply a function to all the elements of an iterable (list, tuple, set, dictionary etc.)
# it returns a map object which can be converted to list, tuple, set etc.
# syntax : map(function, iterable)
l1=[1,2,3,4]
# squared=list(map(lambda x : x**2 , l1))
# print(squared)  
print(list(map(lambda x : x**2 , l1)))

# Filter Function :
# it is used to filter the elements of an iterable (list, tuple, set, dictionary etc.) based on a condition
# it returns a filter object which can be converted to list, tuple, set etc.
# syntax : filter(function, iterable)
even=list(filter(lambda x : x%2==0 , l1))
print(even) 

# Reduce Function :
# it is used to apply a function to all the elements of an iterable (list, tuple, set, dictionary etc.) and reduce it to a single value
# it returns a single value
# syntax : reduce(function, iterable)

from functools import reduce
product=reduce(lambda x,y : x*y , l1)
print(product)  
 
 
# Nested Function :
# it is a function inside a function
# it is used to create a function inside a function to avoid the use of global variables
def outer_function(text):
    def inner_function():
        print(text)
    inner_function()
outer_function("Hello World")   

def fn():
    yield 1
    yield 2
    yield 3
print(fn())
print(fn().__next__())
for i in fn():
    print(i)