#Remove element from dictionary:
# d1.pop('c')
# print(d1)
# d1.popitem()#it will remove the last element of the dictionary
# print(d1)
# #to delete an element from dictionary:
# del d1['b']
# print(d1)
# # del d1 #it will delete the whole dictionary
# # print(d1) #it will give error as the dictionary is deleted
# d1.clear() #it will clear the whole dictionary
# print(d1)
