#Q1--
# Perform Basic Mathematical Operations : 

a=int(input("Enter the 1st number : "))
b=int(input("Enter the 2nd number : "))
print("Addition : ",a+b,"\nSubstraction : ",a-b,"\nMultiplication : ",a*b,"\nDivision : ",a/b)

# Q2--
# Create a Personalized Greeting

fn=input("Enter your First Name : ") 
ln=input("Enter your Last Name : ")
print(f"Hello, {fn} {ln}! welcome to the Python program.")