# #Q1 ---
# d1={"gourav":96,"sagarika":90,"preetam":75,"sudhir":85,"Shivam":88,"Ankita":92,"Rohit":80}
# n=input("Enter the name of student : ")

# l=d1.keys()
# print(l)

# if n in l:
#     print(f"The marks of {n} is : {d1[n]}")
# else:
#     print(f"The name {n} is not found in the dictionary.")
    

#Q2 --
l=[1,2,3,4,5,6,7,8,9,10]
ex=[]
#extract 5 elemetns of the l and storein the ex list:
ex=l[0:5]
print("Original List : ",l)
print("Extract first Five elements : ",ex)
ex.reverse()
print("Reversed extracted elements : ",ex)


