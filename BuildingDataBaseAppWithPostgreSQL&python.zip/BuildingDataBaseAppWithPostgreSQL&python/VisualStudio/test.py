import psycopg2

def table(): #Now put all creation of table code inside the function 
    #Establish the connect b/w python and database : 
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="gourav@95",host="localhost",port="5432") #for its attributes : dbname=""-->it is the name of Database, user="" --> it si alos the username ,password="" -->this is the password, host="" -->is the local host ,port="" --> port 
    #These all above parameter is connect the python with your database and the all info you get from psql terminal
    # #now ot check connected or not add a print statement 
    # print("Connected Successfully..") #Now got to cmd and activate the env as you instal the package in the enviroment and run the file ro you can run it in the terminal of vscode 


    #To create a Table first we have to create a Cursor : 
    cursor=conn.cursor() #hter is no need to pass any attribute in it  
    #Now we have to execute the command that we used to pass inside the pc4
    cursor.execute(''' create table employees(Name text,ID int,Age int);''') #Now execute the command line  which is inside the ''' '''  and after writing the command line put a semicolon   #cursor is nothing but then blinking verticle line in DB 
    print('Table created Successfully') #as  after execution we donot get any message so print it   
    #Once you have tighen this command we have to commit the changes to DB 
    conn.commit()
    #once the commit has saved close it :
    conn.close()
    #We can check above by going to the cmd and type \d enter the employees table is created

#Now we Insert the data inside the table : 
def data():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="gourav@95",host="localhost",port="5432") #for its attributes : dbname=""-->it is the name of Database, user="" --> it si alos the username ,password="" -->this is the password, host="" -->is the local host ,port="" --> port 
   
    cursor=conn.cursor() 
    cursor.execute(''' insert into employees(Name,ID,Age) Values('sudhir',01,23);''') 
    print('Data Inserted Successfully') 
    conn.commit()
    conn.close()
    
# table() #As once table is already created 
# data()

#Now How to extract the data from database using python : 
def extract():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="gourav@95",host="localhost",port="5432") #for its attributes : dbname=""-->it is the name of Database, user="" --> it si alos the username ,password="" -->this is the password, host="" -->is the local host ,port="" --> port 
   
    cursor=conn.cursor() 
    cursor.execute('''select * from employees; ''') 
    
    # print(cursor.fetchone()) #to print the fetch data of database in cmd 
    #We can see the specific data from fetched data : 
    show= cursor.fetchone()
    print(show[0])# As fetchone() return data in form of tuple so can access by index 
    print('Data Extracted Successfully')  
    conn.commit()
    conn.close()
    
# extract() #now run in vs code terminal see the inserted data 

#Now we will see Adding the inputs from user : 
def userinpdata():
    conn=psycopg2.connect(dbname="postgres",user="postgres",password="gourav@95",host="localhost",port="5432") #for its attributes : dbname=""-->it is the name of Database, user="" --> it si alos the username ,password="" -->this is the password, host="" -->is the local host ,port="" --> port 
   
    nm=input("Enter the name : ")
    i=int(input("Enter the id of emplloyee :"))
    age=int(input("Enter the age : "))
    
    
    cursor=conn.cursor() 
    cursor.execute(''' insert into employees(Name,ID,Age) Values(%s,%s,%s);''',(nm,i,age)) #Nowe we are passing dynamic values here #htere may be empty spaces insede this value
    print('UserinputedData Inserted Successfully') 
    conn.commit()
    conn.close()
    
userinpdata() 
    
   