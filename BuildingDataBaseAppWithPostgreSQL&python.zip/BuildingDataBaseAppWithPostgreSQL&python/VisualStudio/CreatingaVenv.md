<h2> <b>To show markdone preview use : ctrl+shift+v or ctrl+k then v </b> </h2>

### <u>To Create a Virtual Enviroment : </u>

<h4>Open CMD --> then cd "path_of_folder_inside_which_want_to_create_venv"-->After entering into that folder --> To <b>Install</b> Type = <b>pip install virtualenv enter</b> </h4>
<h4>After installation of virtual enviroment you have to <b>create a virtual env </b> : by = <b> virtualenv name_of_virtualenv </b></h4>
<h4>Now to activate the virtualenv do : First move into that <b>cd env</b> folder --> then <b>cd scripts enter or we can directly write :<b> cd env\Scripts enter</b> then  --> activate </b>---> And to Deactive it : <b>deactivate enter</b></h4>
<h4>Now to run created file : in CMD of pc goto that folder where your python file present --> then <b>python file_name.py enter</b></h4>

### <u> Install the Package psycopg2 : </u>
<h4>PSYCOPG2= <b>Help to connect python and postgre database for comunicate</b></h4>
<h4>To install it : goto VisuaStudio folder by= cd.. --> then <b>pip install psycopg2==2.8.6 enter</b>---> here we specify the version as to work with the same version</h4>
<h4><b>To showing error : </b><br>
because psycopg2 (non-binary) needs to be compiled from C source code, and your system doesn’t have the required compiler tools --> <b>pip install psycopg2-binary==2.8.6
</b> OR <br><br> Go to <br>👉 https://visualstudio.microsoft.com/visual-cpp-build-tools/

Download Build Tools for Visual Studio.

During installation, select:

✅ “Desktop development with C++” workload.

✅ “MSVC v143” (or later) compiler.

After install completes, restart your terminal.

Then retry: <b>psycopg2==2.8.6 enter</b> </h4>

### <u>Connect To the Database : </u>
<h4>In the test.py python file import psycopg2 then connect</h4>
<h4>If during run show Erro install psycopg=2.9.9 version by command : <br> 
<b>
pip uninstall psycopg2 -y<br>
pip install psycopg2-binary==2.9.9
</b>
</h4>

<h4>
If you want to keep the non-binary version (for production or special setups):<br>

Install PostgreSQL from the official site:<br>
👉 https://www.postgresql.org/download/windows/
<br>
During setup, make sure “Command Line Tools” and “psql” are selected.
<br>
Add PostgreSQL’s bin folder to your PATH manually, for example:
<b>C:\Program Files\PostgreSQL\18\bin</b>
</h4>

### <u>How to create a Table using python : <b>See test.py file</b></u>
<h4></h4>
<h4></h4>
<h4></h4>
<h4></h4>
<h4></h4>
<h4></h4>
<h4></h4>
<h4></h4>
<h4></h4>