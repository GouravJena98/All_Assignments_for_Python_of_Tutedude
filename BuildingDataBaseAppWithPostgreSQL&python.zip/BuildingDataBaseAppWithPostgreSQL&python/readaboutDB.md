<h2> <b>To show markdone preview use : ctrl+shift+v or ctrl+k then v </b> </h2>

## <u>DATA :</u>
<p>
Collection of Information <br>
It is derived from the word DATUM =single piece of Information i.e data is plural but the datam is singular
<b>ex : Data of person : Name,age,dob,gender,nationality</b>
<p>And the Data is in the form of : Text,number=age,dob,media=photo,etc</p>
<p>Earlier it was stored physically in the files and notebook in the store room But now store in form of bytes in digitally</>
</p>

## <u>DataBase : </u>
<p>
<h3>What is Base : </h3>
<h4>It is a basement like structure which provides a structure to the Data to store in a arranged/organized manner i.e organized means <b>"Table by means of Rows and columns.."</b><br>And we can Easily Access,Manage,Update it .</h4>
<h4>Like In construction of House ,initially the basement is laid in a organized manner so that we can construct the roons and building in the planned way . </h4>
<h4>i.e <b>DATA + BASE = DATABASE</b></h4>

![Project Logo](database.jpg)

### Main Purpose of DataBase : 
<h4>To Operate Large amount of Information by Storing,Retriveing and Manaing them.</h4>
<h4>How to store,Retrieve,manage,Secure the data by pass key<\h4>
<h4>Many Database are there : </h4>
<ul>
<li>MySQL</li>
<li>ORACLE</li>
<li>PostregSQL</li>
<li>MongoDB</li>etc...
</ul>
</p>

<p>
## PostgreSQL : 

<h3>Types of DB : </h3>

![Project Logo](TypesOfDB.jpg)

<h3>Relational DB: </h3>

![Project Logo](RelationalDB.jpg)

<h3>PostgreSQL DB : </h3>

![Project Logo](PostgreSQL.jpg)

</p>

<p>
<h3><b>After installing the PostgreSQL : </b></h3>
<h4>goto start -> press pg enter--> so a PgAdmin interface will open wehre you can see your database ,table, and can mange it </h4> OR 
<h4>goto start -> type psql-> then press enter utill get the password and after giving the password you will enter into server .</h4>
</p>

<p>

# <u>Now to Create a DataBase using Psql cmd : </u>
<h4> <b> <u>Note -- </u> In all the places of Capital letter word we can also write small letter word</b> </h4>
## <u>Create ,switch ,Delete Database : </u>
<h4>Initially the server is at local host server </h4>
<h4>To see what are the databases is available in the shell -><b> \l enter </b></h4>
<h4>To create a Database -> <b>create database name_of_database; </b></h4>
<h4>To switch from one Database to another (i.e we switch from current database where you are from another)use -> <b> \c name_of_db_wantToSwitch </b> </h4>
<h4>To Delete the DataBase use -> <b> drop database name_of_database_wantToDelete; </b></h4>

## <u>How to create a Table and Add, Retrive and Delete data in it : </u>
<h4>To create Table -->  <b>CREATE TABLE name_of_table(col1_name datatype1,col2_name datatype2); </b></h4> Here for string use datatype = text and for number use = int 
<h4>Ex-- CREATE TABLE student(name text,number int,age int);</h4>
<h4>To see the tables lists -> <b>\d enter </b> </h4> so get list of relation 
<h4>To insert the rows in table use -> <b> INSERT INTO name_of_table(here arrange the column name as per you want either in the same order or in rnadom order) VALUES('gourav',4,44); </b> </h4> Here single quote is allowed for string not double quote
<h4>Ex-- INSERT INTO student(name,age,number) VALUES('hari',22,9);</h4>
<h4>To delete any relation or Table do -> <b>delete relation name_of_table;</b> </h4>

### Retrive Data :  
<h4>To Retrieve all the Data of a Table --> <b> SELECT * FROM name_of_table; </b> </h4> 
<h4>Ex -- select * from student;</h4>
<h4>For showing the specific column data --> <b>SELECT name_of_col FROM name_of_table; </b></h4>
<h4>Ex -- select name from student;</h4>
<h4>To FILTER Data : --> <b> SELECT * FROM name_of_table WHERE condition; </b></h4>
<h4>Ex -- select * from student where number=10;</h4>
<h4>We can also mix both i.e show specific column after applying the filter --> <b>SELECT name_fo_col FROM name_of_table WHERE condition; </b></h4>
<h4>Ex-- select age from student where number=9</h4>
<h4>To Delete the Content of the Table but the table remain exhist --> <b> TRUNCATE TABLE name_of_table;</b> </h4>
<h4></h4>
<h4></h4>
<h4></h4>
</p>